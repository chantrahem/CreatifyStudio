<?php
// Configuration file for QRMMS

// Site Information
define('SITE_NAME', 'QRMMS');
define('SITE_TAGLINE', 'Quality Resource Management & Marketing Solutions');
define('SITE_URL', 'https://www.qrmms.com');
define('SITE_EMAIL', 'contact@qrmms.com');
define('SITE_PHONE', '+855 69 71 21 21');

// Company Information
define('COMPANY_NAME', 'QRMMS');
define('COMPANY_ADDRESS', 'Siem Reap, Kingdom of Cambodia');
define('COMPANY_FOUNDED', '2020');

// Social Media Links
define('SOCIAL_FACEBOOK', 'https://facebook.com/qrmms');
define('SOCIAL_TWITTER', 'https://twitter.com/qrmms');
define('SOCIAL_INSTAGRAM', 'https://instagram.com/qrmms');
define('SOCIAL_LINKEDIN', 'https://linkedin.com/company/qrmms');
define('SOCIAL_GITHUB', 'https://github.com/qrmms');

// Services Configuration
$services = [
    'web-development' => [
        'title' => 'Web Development',
        'icon' => 'code',
        'description' => 'Custom websites and web applications built with modern technologies',
        'features' => [
            'Responsive Design',
            'E-commerce Solutions', 
            'CMS Development',
            'API Integration',
            'Performance Optimization',
            'SEO Optimization'
        ],
        'technologies' => ['PHP', 'JavaScript', 'React', 'Vue.js', 'Laravel', 'WordPress'],
        'pricing_from' => '$750'
    ],
    'graphic-design' => [
        'title' => 'Graphic Design',
        'icon' => 'palette',
        'description' => 'Creative visual solutions for your brand identity and marketing materials',
        'features' => [
            'Logo Design',
            'Brand Identity',
            'Print Design',
            'Social Media Graphics',
            'UI/UX Design',
            'Marketing Materials'
        ],
        'technologies' => ['Adobe Creative Suite', 'Figma', 'Sketch', 'Canva Pro'],
        'pricing_from' => '$299'
    ],
    'domain-hosting' => [
        'title' => 'Domain & Hosting',
        'icon' => 'server',
        'description' => 'Reliable domain registration and web hosting solutions for your online presence',
        'features' => [
            'Domain Registration',
            'Shared Hosting',
            'VPS Hosting',
            'SSL Certificates',
            'Email Hosting',
            'Daily Backups'
        ],
        'technologies' => ['cPanel', 'CloudFlare', 'Let\'s Encrypt', 'SSD Storage'],
        'pricing_from' => '$9.99/month'
    ]
];

// Featured QR Menu System Configuration
$qr_menu_system = [
    'title' => 'QR Menu Management System',
    'icon' => 'qrcode',
    'description' => 'Digital menu platform for restaurants, cafes, and bars that saves money on menu printing and graphic design',
    'features' => [
        'Clean & Responsive Display',
        'Easy ON/OFF Items Control',
        'Desktop & Mobile Backend',
        'Real-time Menu Updates',
        'QR Code Generation',
        'Manage Menu Anywhere, Anytime',
        'Post Sale',
        'Print Receipt',
        'Menu in Multiple Languages (Khmer, English, Chinese)'
    ],
    'technologies' => ['QR Code Technology', 'Mobile Responsive', 'Cloud-based', 'Real-time Updates'],
    'pricing_from' => 'Contact for Demo'
];

// Navigation Menu
$navigation = [
    'Home' => '/',
    'QR Menu System' => '/services/qr-menu-system.php',
    'Services' => [
        'All Services' => '/services.php',
        'divider' => true,
        'Web Development' => '/services/web-development.php',
        'Graphic Design' => '/services/graphic-design.php',
        'Domain & Hosting' => '/services/domain-hosting.php'
    ],
    'Portfolio' => '/portfolio.php',
    'About' => '/about.php',
    'Contact' => '/contact.php'
];

// Testimonials
$testimonials = [
    [
        'name' => 'Sarah Johnson',
        'company' => 'TechStart Inc.',
        'position' => 'CEO',
        'message' => 'QRMMS transformed our online presence with a stunning website that perfectly captures our brand. Their attention to detail and professionalism exceeded our expectations.',
        'rating' => 5,
        'image' => 'testimonial-1.jpg'
    ],
    [
        'name' => 'Michael Chen',
        'company' => 'Urban Cafe',
        'position' => 'Owner',
        'message' => 'The team created an amazing e-commerce solution for our restaurant. Orders increased by 40% since launch, and customers love the user-friendly design.',
        'rating' => 5,
        'image' => 'testimonial-2.jpg'
    ],
    [
        'name' => 'Emily Rodriguez',
        'company' => 'Creative Agency',
        'position' => 'Marketing Director',
        'message' => 'Outstanding graphic design work! Our new brand identity has received incredible feedback from clients and partners. Highly recommended!',
        'rating' => 5,
        'image' => 'testimonial-3.jpg'
    ]
];

// Portfolio Projects
$portfolio = [
    [
        'title' => 'Snaca Cafe Digital Solution',
        'category' => 'qr-menu-system',
        'client' => 'Snaca Cafe',
        'description' => 'Complete digital transformation with domain registration, hosting setup, and QR menu management system',
        'technologies' => ['Domain Registration', 'Web Hosting', 'QR Menu System', 'Multi-Language'],
        'image' => 'portfolio-snacacafe.jpg',
        'url' => 'https://snacacafe.com'
    ],
    [
        'title' => 'Miss Salmon Restaurant Platform',
        'category' => 'qr-menu-system',
        'client' => 'Miss Salmon',
        'description' => 'Digital menu platform with hosting and domain management for seamless restaurant operations',
        'technologies' => ['Domain Registration', 'Web Hosting', 'QR Menu System', 'Receipt Printing'],
        'image' => 'portfolio-misssalmon.jpg',
        'url' => 'https://misssalmon.com'
    ],
    [
        'title' => 'Mlob Mean Full-Stack Development',
        'category' => 'web-development',
        'client' => 'Mlob Mean',
        'description' => 'Complete restaurant website development with custom features, hosting, and advanced QR menu system',
        'technologies' => ['Custom Website', 'PHP', 'QR Menu System', 'Domain & Hosting'],
        'image' => 'portfolio-mlobmean.jpg',
        'url' => 'https://mlobmean.com'
    ],
    [
        'title' => 'Hillocks Hotel Website',
        'category' => 'web-development',
        'client' => 'Hillocks Hotel',
        'description' => 'Professional hotel website with booking system, gallery, and responsive design',
        'technologies' => ['Custom Development', 'Responsive Design', 'Booking System', 'CMS'],
        'image' => 'portfolio-hillockshotel.jpg',
        'url' => 'https://hillockshotel.com'
    ],
    [
        'title' => 'Takak Villas Luxury Website',
        'category' => 'web-development',
        'client' => 'Takak Villas',
        'description' => 'Elegant villa rental website with advanced booking features and stunning visual presentation',
        'technologies' => ['Custom Development', 'Booking Engine', 'Gallery System', 'SEO'],
        'image' => 'portfolio-takakvillas.jpg',
        'url' => 'https://takakvillas.com'
    ],
    [
        'title' => 'Sanna Villa Resort Website',
        'category' => 'web-development',
        'client' => 'Sanna Villa',
        'description' => 'Modern resort website with reservation system, amenities showcase, and mobile optimization',
        'technologies' => ['Custom Development', 'Reservation System', 'Mobile First', 'Performance'],
        'image' => 'portfolio-sannavilla.jpg',
        'url' => 'https://sannavilla.com'
    ]
];

// Contact Form Settings
define('CONTACT_EMAIL', SITE_EMAIL);
define('CONTACT_SUBJECT_PREFIX', '[QRMMS Contact] ');

// Error and Success Messages
$messages = [
    'contact_success' => 'Thank you for your message! We\'ll get back to you within 24 hours.',
    'contact_error' => 'Sorry, there was an error sending your message. Please try again.',
    'validation_error' => 'Please fill in all required fields correctly.',
    'email_invalid' => 'Please enter a valid email address.'
];

// Helper Functions
function getCurrentPage() {
    $page = $_SERVER['REQUEST_URI'];
    $page = parse_url($page, PHP_URL_PATH);
    $page = trim($page, '/');
    return empty($page) ? 'home' : $page;
}

function isActivePage($page) {
    $current = getCurrentPage();
    return $current === $page ? 'active' : '';
}

function formatPrice($price) {
    return is_numeric($price) ? '$' . number_format($price, 2) : $price;
}

function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function generateStars($rating) {
    $stars = '';
    for ($i = 1; $i <= 5; $i++) {
        if ($i <= $rating) {
            $stars .= '<i class="fas fa-star text-yellow-400"></i>';
        } else {
            $stars .= '<i class="far fa-star text-gray-300"></i>';
        }
    }
    return $stars;
}
?>